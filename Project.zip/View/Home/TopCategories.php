<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EduSpace</title>
</head>

<body>
    <div class="categories-container">
        <div>
            <h3 class="section-title">Our Categories</h3>
            <div class="categories container">
                <div class="right">
                    <div class="categories-cards">
                        <!-- 1 -->
                        <div class="service-card">
                            <img src="View/Assets/service-1.svg" alt="">
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc </p>
                            <br>
                            <b>Courses</b>
                        </div>
                        <!-- 2 -->
                        <div class="service-card">
                            <img src="View/Assets/service-1.svg" alt="">
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc </p>
                            <br>
                            <b>Courses</b>
                        </div>
                        <!-- 3 -->
                        <div class="service-card">
                            <img src="View/Assets/service-1.svg" alt="">
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc </p>
                            <br>
                            <b>Courses</b>
                        </div>
                        <!-- 4 -->
                        <div class="service-card">
                            <img src="View/Assets/service-1.svg" alt="">
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc </p>
                            <br>
                            <b>Courses</b>
                        </div>
                        <!-- 5 -->
                        <div class="service-card">
                            <img src="View/Assets/service-1.svg" alt="">
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc </p>
                            <br>
                            <b>Courses</b>
                        </div>
                        <!-- 6 -->
                        <div class="service-card">
                            <img src="View/Assets/service-1.svg" alt="">
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc </p>
                            <br>
                            <b>Courses</b>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>

</html>